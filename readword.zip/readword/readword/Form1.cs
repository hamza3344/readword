﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Word;

namespace readword
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
            object miss = System.Reflection.Missing.Value;
            object path = @"C:\sample\demo.docx";
            object readOnly= true;
            Document docs = word.Documents.Open(ref path, ref miss, ref readOnly, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss);//13 times ref miss
            string totaltext = "";
            foreach(Paragraph p in docs.Paragraphs)
            {
                totaltext += p.Range.Text.ToString();
            }
            foreach(Table table in docs.Tables)
            {
                for(int row=1;row<=table.Rows.Count;row++)
                {
                    for(int col=1;col<=table.Columns.Count;col++)
                    {
                        string data = table.Cell(row, col).Range.Text;
                        textBox1.AppendText(data + "|");
                    }
                    textBox1.AppendText(Environment.NewLine);
                }
            }
            richTextBox1.Text = totaltext;
            docs.Close();
            word.Quit();
        }
    }
}
